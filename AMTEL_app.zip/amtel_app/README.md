# AMTEL app
Android application which helps to organize an amateur tennis league. The application is a practical part of my Bachelor thesis at CTU in Prague.
