package cz.prague.cvut.fit.steuejan.amtelapp.data.util

enum class RankingOrderBy
{
    POINTS, MATCHES, WINS, LOSSES, POSITIVE_SETS, NEGATIVE_SETS
}