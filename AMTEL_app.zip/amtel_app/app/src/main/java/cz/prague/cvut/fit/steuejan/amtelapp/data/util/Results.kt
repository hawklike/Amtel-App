package cz.prague.cvut.fit.steuejan.amtelapp.data.util

data class Results(val sets: String, val games: String)
data class MatchResult(val home: Int, val away: Int)