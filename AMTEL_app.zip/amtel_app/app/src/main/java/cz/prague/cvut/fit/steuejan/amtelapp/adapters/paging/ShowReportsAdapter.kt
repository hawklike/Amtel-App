package cz.prague.cvut.fit.steuejan.amtelapp.adapters.paging

import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.firestore.paging.FirestorePagingAdapter
import com.firebase.ui.firestore.paging.FirestorePagingOptions
import com.google.firebase.firestore.ktx.toObject
import cz.prague.cvut.fit.steuejan.amtelapp.business.util.toMyString
import cz.prague.cvut.fit.steuejan.amtelapp.data.entities.Report
import cz.prague.cvut.fit.steuejan.amtelapp.data.entities.User
import cz.prague.cvut.fit.steuejan.amtelapp.data.util.UserRole.HEAD_OF_LEAGUE
import cz.prague.cvut.fit.steuejan.amtelapp.data.util.toRole
import cz.prague.cvut.fit.steuejan.amtelapp.databinding.ReportCardBinding

class ShowReportsAdapter(options: FirestorePagingOptions<Report>, private val user: User?)
    : FirestorePagingAdapter<Report, ShowReportsAdapter.ViewHolder>(options)
{
    var onClick: ((report: Report?) -> Unit)? = null
    var onEdit: ((report: Report?) -> Unit)? = null

    inner class ViewHolder(val binding: ReportCardBinding) : RecyclerView.ViewHolder(binding.root)
    {
        init
        {
            binding.card.setOnClickListener {
                onClick?.invoke(getReport(adapterPosition))
            }

            binding.edit.setOnClickListener {
                onEdit?.invoke(getReport(adapterPosition))
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder
    {
        val binding = ReportCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int, report: Report)
    {
        with(holder.binding) {
            title.text = report.title
            lead.text = report.lead
            date.text = report.date.toMyString()

            if(user?.role?.toRole() == HEAD_OF_LEAGUE)
                edit.visibility = VISIBLE
            else
                edit.visibility = GONE
        }
    }

    private fun getReport(position: Int): Report?
            =  getItem(position)?.toObject<Report>()
}