package cz.prague.cvut.fit.steuejan.amtelapp.data.util

data class Message(val title: String, val message: String?)